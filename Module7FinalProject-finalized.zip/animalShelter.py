#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 26 03:21:59 2023

@author: charlesadkins_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId
import json

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        #USER = 'aacuser1'
        #PASS = 'Bingo23459'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30055
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print("Connection Successful")
        
        
# Complete this create method to implement the C in CRUD.
    def create(self, data=None):
        if data is not None:
        	#insert document into collection based upon parameter values provided
            self.database.animals.insert_one(data)  
            return True
               
                  
        else:
            return False



# Create method to implement the R in CRUD.

    def read(self, data):
        if data is not None:
            #find documents that match the data parameter provided
            return self.database.animals.find(data,{"_id":False}) 
            
        else:
        
            raise Exception("Nothing to return, because data parameter is empty")

                

#Method to implement U in CRUD

    def update(self, find=None, replace=None):
        if find is not None:
        	#update all documents that meet the 'find' parameters and replace them
            x = self.database.animals.update_many(find, {"$set":replace})
            #output the count of records updated
            return ("\r", str(x.modified_count) + " records updated")
            
        else:
            raise Exception("Nothing to return because data parameter is empty.")
   		
   		

#Method to implement D in CRUD

    def delete(self, data=None):
        if data is not None:
        	#delete all documents that meet the data parameter entered
            x = self.database.animals.delete_many(data)
            	#output the count of record(s) deleted
            print(x.deleted_count, " record(s) deleted")
            
        else:
            raise Exception("Nothing to delete because data parameter is empty.")
            
            
            
            
